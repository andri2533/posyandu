<?php 

function db(){
	$host="localhost";
	// $user = "andriin1_user";
	// $pass = "@ndri100795";
	// $db ="andriin1_mydb";
	$user = "root";
	$pass = "";
	$db ="posyandu";
	$konek=new mysqli($host, $user, $pass,$db);
	if(!$konek){
		echo "Database Not found";
	}

	return $konek;
}

function base_url($link=''){
	return "http://localhost/posyandu".$link;	
	// return "http://andri.in/posyandu".$link;	
}

?>