<?php 
// print(getUri(3));
$action=$_REQUEST['action'];
switch ($action) {
	case 'add':
		$ayah=$_REQUEST['ayah'];
		$ibu=$_REQUEST['ibu'];
		$alamat=$_REQUEST['alamat'];
		$field=" ayah, ibu, alamat, tanggal_masuk ";
		$value=" '$ayah', '$ibu', '$alamat', now() ";
		$insert=insertTable('t_ortu', $field, $value);
		if($insert){
			echo "Sukses";
		}else{
			echo "Tambah data gagal.";
		}
		break;
	case 'update':
		$id_ortu=$_REQUEST['id_ortu'];
		$ayah=$_REQUEST['ayah'];
		$ibu=$_REQUEST['ibu'];
		$alamat=$_REQUEST['alamat'];
		$field=" ayah = '$ayah', ibu = '$ibu', alamat = '$alamat' ";
		$where=" id_ortu = '$id_ortu' ";
		$update=updateTable('t_ortu', $field, $where );
		if($update){
			echo "Sukses";
		}else{
			echo "Update data gagal.";
		}
		break;
	case 'delete':
		$id_ortu=$_REQUEST['id_ortu'];
		$delete=deleteTable('t_ortu'," id_ortu = '$id_ortu' ");
		if($delete){
			echo "Sukses";
		}else{
			echo "Hapus data gagal";
		}
		break;
	default:
		$data=selectTable("SELECT * FROM t_ortu ", "array");
		foreach ($data as $row) {
			if($row['tanggal_masuk']){
				$row['tanggal_masuk']=@(substr($row['tanggal_masuk'], 0,10));
			}else{
				$row['tanggal_masuk']='-';
			}
			if($row['alamat']){
				
			}else{
				$row['alamat']='-';
			}
			array_push($return, $row);
		}
		echo json_encode($return);
		break;
}
?>