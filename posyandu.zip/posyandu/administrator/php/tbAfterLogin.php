<?php 
// print(getUri(3));
$action=$_REQUEST['action'];
switch ($action) {
	// case 'copy':
	// 	$id_anak=$_REQUEST['id_anak'];
	// 	$umur=$_REQUEST['umur'];
	// 	$berat=$_REQUEST['berat'];
	// 	$panjang=$_REQUEST['panjang'];
	// 	$imunisasi=@($_REQUEST['imunisasi'])?$imunisasi:'-';
	// 	$vitamin=@($_REQUEST['vitamin'])?$imunisasi:'-';
	// 	$tanggal_timbang=$_REQUEST['tanggal_timbang'];
	// 	$field="id_anak, umur_anak, berat_badan, panjang_badan, imunisasi, vitamin, tanggal_timbang ";
	// 	$value=" '$id_anak', '$umur', '$berat', '$panjang', '$imunisasi', '$vitamin', '$tanggal_timbang' ";
	// 	$insert=insertTable('t_laporan_anak', $field, $value);
	// 	if($insert){
	// 		echo "Sukses";
	// 	}else{
	// 		echo "Tambah data gagal.";
	// 	}
	// 	break;
	case 'add':
		$id_anak=$_REQUEST['id_anak'];
		$umur=$_REQUEST['umur'];
		$berat=$_REQUEST['berat'];
		$panjang=$_REQUEST['panjang'];
		$imunisasi=@($_REQUEST['imunisasi']);
		$vitamin=@($_REQUEST['vitamin']);
		$tanggal_timbang=$_REQUEST['tanggal_timbang'];
		$field="id_anak, umur_anak, berat_badan, panjang_badan, imunisasi, vitamin, tanggal_timbang ";
		$value=" '$id_anak', '$umur', '$berat', '$panjang', '$imunisasi', '$vitamin', '$tanggal_timbang' ";
		$insert=insertTable('t_laporan_anak', $field, $value);
		if($insert){
			echo "Sukses";
		}else{
			echo "Tambah data gagal.";
		}
		break;
	case 'update':
		$id_laporan=$_REQUEST['id_laporan'];
		$umur=$_REQUEST['umur'];
		$berat=$_REQUEST['berat'];
		$panjang=$_REQUEST['panjang'];
		$imunisasi=$_REQUEST['imunisasi'];
		$vitamin=$_REQUEST['vitamin'];
		$field=" umur_anak = '$umur', berat_badan = '$berat', panjang_badan = '$panjang', imunisasi ='$imunisasi', vitamin = '$vitamin' ";
		$where=" id_laporan = '$id_laporan' ";
		$update=updateTable('t_laporan_anak', $field, $where );
		if($update){
			echo "Sukses";
		}else{
			echo "Update data gagal.";
		}
		break;
	case 'delete':
		$id_laporan=$_REQUEST['id_laporan'];
		$delete=deleteTable('t_laporan_anak'," id_laporan = '$id_laporan' ");
		if($delete){
			echo "Sukses";
		}else{
			echo "Hapus data gagal";
		}
		break;
	case 'tb2':
		// print(getUri(3));
		$data=selectTable("SELECT * FROM t_laporan_anak WHERE id_anak = '".$_GET['id_anak']."' ORDER BY tanggal_timbang ASC ", "array");
		// $data=selectTable("SELECT * FROM t_laporan_anak WHERE id_anak = '".$__GET['id_anak']."' AND (berat_anak != '-' OR Imunisasi != '-' OR Vitamin != '-') ", "array");
		foreach ($data as $row) {
			$row['tanggal_timbang']=substr($row['tanggal_timbang'], 0, 10);
			$row['umur_anak'].=" Bulan";
			$row['berat_badan'].=" Kg";
			$row['panjang_badan'].=" Cm";
			if($row['imunisasi']==''){
				$row['imunisasi']='-';
			}

			if($row['vitamin']==''){
				$row['vitamin']='-';
			}
			array_push($return, $row);
		}
		echo json_encode($return);
		break;
	default:
		$page  = isset($_POST['page']) ? intval($_POST['page']) : 1;
		$rows  = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
		$sort  = isset($_POST['sort']) ? strval($_POST['sort']) : 'id_anak';
		$order = isset($_POST['order'])? strval($_POST['order']): 'ASC';
		$offset= ($page - 1) * $rows;

		$data=selectTable("SELECT * FROM t_anak ORDER BY $sort $order ", "array");
		$anak=array();
		$items=array();
		$return['total']=count($data);
		$x=0;
		foreach ($data as $row) {
			$ortu=selectTable("SELECT * FROM t_ortu WHERE id_ortu = '".$row['id_ortu']."' ");
			$umur=getUsia($row['tanggal_lahir']);
			if($umur['Y']==0){
				$umur=$umur['m']." Bulan";
			}else{
				$umur=$umur['Y']." Tahun ".$umur['m']." Bulan";
			}
			$anak[$i]['nama_anak']=$row['nama_anak'];
			$anak[$i]['id_anak']=$row['id_anak'];
			$anak[$i]['berat_badan']=$row['berat_badan']." Kg";
			$anak[$i]['panjang_badan']=$row['panjang_badan']." Cm";
			$anak[$i]['tanggal_lahir']=$row['tanggal_lahir'];
			$anak[$i]['umur_anak']=$umur;
			if($row['jk']==1){
				$anak[$i]['jk']="L";
			}else{
				$anak[$i]['jk']="P";
			}
			$anak[$i]['ayah']=$ortu['ayah'];
			$anak[$i]['ibu']=$ortu['ibu'];
			array_push($items, $anak[$i]);
			$x++;
		}
		$return['rows']=$items;
		echo json_encode($return);
		break;
}
?>