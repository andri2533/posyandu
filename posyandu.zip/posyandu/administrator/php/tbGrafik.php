<?php

// untuk update data 
if(isset($_REQUEST['usia'])){
	$usia=$_REQUEST['usia'];
	$col=$_REQUEST['batas'];
	if($col=='Batas Atas'){
		$col='ba';
	}elseif($col=='Batas Atas 2'){
		$col='ba2';
	}elseif($col=='Batas Atas 3'){
		$col='ba3';
	}elseif($col=='center'){
		$col='center';
	}elseif($col=='Batas Bawah 3'){
		$col='bb3';
	}elseif($col=='Batas Bawah 2'){
		$col='bb2';
	}elseif($col=='Batas Bawah'){
		$col='bb';
	}
	$isi= str_replace(',', '.', $_REQUEST['isi']);

	$update=updateTable('t_berat_badan', $col."= '".$isi."' ", " usia = '".$usia."' " );
	// if(!$update){
	// 	echo "Gagal update.";
	// }

	print_r($update);
	echo "<br>";
	echo $usia;
	echo "<br>";
	echo $col;
	echo "<br>";
	echo $isi;

	exit();
}

$page = isset($_GET['p']) ? intval($_GET['p']) : 1;
$limit= isset($_GET['i']) ? intval($_GET['i']) : 5;
$offset=($page-1)*$limit;

$value=selectTable("SELECT * FROM t_berat_badan LIMIT $offset, $limit ","array");
// $value=selectTable("SELECT * FROM t_berat_badan ","array");
$categori=array();
$batasAtas=array();
$batasAtas2=array();
$batasAtas3=array();
$batasBawah=array();
$batasBawah2=array();
$batasBawah3=array();
$center=array();
foreach ($value as $row) {
	// $row['usia']=$row['usia']." Bulan";
	array_push($categori, $row['usia']);
	array_push($batasAtas, (float) $row['ba']);
	array_push($batasAtas2, (float) $row['ba2']);
	array_push($batasAtas3, (float) $row['ba3']);
	array_push($center, (float) $row['center']);
	array_push($batasBawah, (float) $row['bb']);
	array_push($batasBawah2, (float) $row['bb2']);
	array_push($batasBawah3, (float) $row['bb3']);
}

	// echo json_encode($batasBawah3);
?>