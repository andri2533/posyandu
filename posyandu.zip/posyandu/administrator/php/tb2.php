<?php 
	// print(getUri(3));
	$data=selectTable("SELECT * FROM t_laporan_anak WHERE id_anak = '".$_GET['id_anak']."' ORDER BY tanggal_timbang ASC ", "array");
	// $data=selectTable("SELECT * FROM t_laporan_anak WHERE id_anak = '".$__GET['id_anak']."' AND (berat_anak != '-' OR Imunisasi != '-' OR Vitamin != '-') ", "array");
	foreach ($data as $row) {
		$row['tanggal_timbang']=substr($row['tanggal_timbang'], 0, 10);
		$row['umur_anak'].=" Bulan";
		$row['berat_badan'].=" Kg";
		$row['panjang_badan'].=" Cm";
		if($row['imunisasi']==''){
			$row['imunisasi']='-';
		}

		if($row['vitamin']==''){
			$row['vitamin']='-';
		}
		array_push($return, $row);
	}
	echo json_encode($return);
?>