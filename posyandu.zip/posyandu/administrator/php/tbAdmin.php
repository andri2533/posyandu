<?php 
// print(getUri(3));
$action=$_REQUEST['action'];
switch ($action) {
	case 'add':
		$username=$_REQUEST['username'];
		$password=$_REQUEST['password'];
		$level=$_REQUEST['level'];
		$field=" username, password, level ";
		$value=" '$username', '$password', '$level' ";
		$insert=insertTable('t_admin', $field, $value);
		if($insert){
			echo "Sukses";
		}else{
			echo "Tambah data gagal.";
		}
		break;
	case 'update':
		$id_admin=$_REQUEST['id_admin'];
		$username=$_REQUEST['username'];
		$password=$_REQUEST['password'];
		$level=$_REQUEST['level'];
		$field=" username = '$username', password = '$password', level = '$level' ";
		$where=" id_admin = '$id_admin' ";
		$update=updateTable('t_admin', $field, $where );
		if($update){
			echo "Sukses";
		}else{
			echo "Update data gagal.";
		}
		break;
	case 'delete':
		$id_admin=$_REQUEST['id_admin'];
		$delete=deleteTable('t_admin'," id_admin = '$id_admin' ");
		if($delete){
			echo "Sukses";
		}else{
			echo "Hapus data gagal";
		}
		break;
	default:
		$data=selectTable("SELECT * FROM t_admin ", "array");
		foreach ($data as $row) {
			$row['password']="*****";
			array_push($return, $row);
		}
		echo json_encode($return);
		break;
}
?>