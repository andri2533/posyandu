<?php
$__JSON=$_REQUEST['for'];
$return=array();

include$__JSON.".php";

?>