<?php 


if($to=='logout'){
unset($_SESSION['admin']); ?>
<script language='javascript'>
	document.location='<?= base_url("/administrator"); ?>';
</script>
<?php }else{
	$user=$_REQUEST['username'];
	$pass=$_REQUEST['pass'];

	$a=selectTable("SELECT * FROM t_admin WHERE username = '$user' AND password  = '$pass' ");
	if($a){
		$_SESSION['admin']=$a;
		header("Location:".base_url('/administrator'));
	}else{
		header("Location:".base_url('/administrator'));
	}
}

?>