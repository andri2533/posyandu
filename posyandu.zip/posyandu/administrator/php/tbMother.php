<?php 
// print(getUri(3));
$action=$_REQUEST['action'];
switch ($action) {
	case 'add':
		$id_ortu=$_REQUEST['id_ortu'];
		$tinggi_badan=$_REQUEST['tinggi_badan'];
		$berat=$_REQUEST['berat'];
		$lingkar_lengan=$_REQUEST['lingkar_lengan'];
		$lingkar_pinggang=$_REQUEST['lingkar_pinggang'];
		$field="id_ortu, berat_badan, tinggi_badan, lingkar_lengan, lingkar_pinggang, tanggal_timbang ";
		$value=" '$id_ortu', '$berat', '$tinggi_badan', '$lingkar_lengan', '$lingkar_pinggang', now() ";
		$insert=insertTable('t_laporan_ibu', $field, $value);
		if($insert){
			echo "Sukses";
		}else{
			echo "Tambah data gagal.";
		}
		break;
	case 'update':
		$id_laporan=$_REQUEST['id_laporan'];
		$tinggi_badan=$_REQUEST['tinggi_badan'];
		$berat=$_REQUEST['berat'];
		$lingkar_lengan=$_REQUEST['lingkar_lengan'];
		$lingkar_pinggang=$_REQUEST['lingkar_pinggang'];
		$field=" berat_badan = '$berat', tinggi_badan = '$tinggi_badan', lingkar_lengan ='$lingkar_lengan', lingkar_pinggang = '$lingkar_pinggang' ";
		$where=" id_laporan = '$id_laporan' ";
		$update=updateTable('t_laporan_ibu', $field, $where );
		if($update){
			echo "Sukses";
		}else{
			echo "Update data gagal.";
		}
		break;
	case 'delete':
		$id_laporan=$_REQUEST['id_laporan'];
		$delete=deleteTable('t_laporan_ibu'," id_laporan = '$id_laporan' ");
		if($delete){
			echo "Sukses";
		}else{
			echo "Hapus data gagal";
		}
		break;
	case 'get':
		$id_ortu=$_GET['id_ortu'];
		$data=selectTable("SELECT * FROM t_laporan_ibu WHERE id_ortu = '$id_ortu' ","array");
		foreach ($data as $row) {
			$row['tanggal_timbang']=substr($row['tanggal_timbang'], 0,10);
			$row['berat_badan'].=" Kg";
			$row['tinggi_badan'].=" Cm";
			$row['lingkar_lengan'].=" Cm";
			$row['lingkar_pinggang'].=" Cm";
			array_push($return, $row);
		}
		echo json_encode($return);
		break;
	default:
		$count=selectTable("SELECT COUNT(*) AS total FROM t_ortu ");
		$return['total']=$count['total'];
		$page  = isset($_POST['page']) ? intval($_POST['page']) : 1;
		$rows  = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
		$sort  = isset($_POST['sort']) ? strval($_POST['sort']) : 'id_ortu';
		$order = isset($_POST['order'])? strval($_POST['order']): 'ASC';
		$offset= ($page - 1) * $rows;

		$data=selectTable("SELECT * FROM t_ortu ORDER BY $sort $order LIMIT $offset, $rows ", "array");
		$items=array();
		foreach ($data as $row) {
			if($row['tanggal_masuk']!=''){
				$row['tanggal_masuk']=substr($row['tanggal_masuk'], 0,10);
			}else{
				$row['tanggal_masuk']='-';
			}
			array_push($items, $row);
		}

		$return['rows']=$items;
		echo json_encode($return);
		break;
}
?>