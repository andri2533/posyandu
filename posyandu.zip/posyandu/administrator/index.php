<?php
include"../function.php";
$admin=getUri(1);
$to=getUri(2);
if(isset($_SESSION['admin'])){
	switch ($to) {
		case 'app':
			include"php/index.php";
			break;
		case 'logout':
			include"php/login.php";
			break;
		case 'mb':
			include"page/balita.php";
			break;
		case 'mo':
			include"page/orgt.php";
			break;
		case 'mg':
			include"php/tbGrafik.php";
			include"page/grafik.php";
			break;
		case 'admin':
			include"page/admin.php";
			break;
		case 'mother':
			include"page/mother.php";
			break;
		case 'child':
			include"page/afterLogin.php";
			break;
		default:
			include"page/afterLogin.php";
			break;
	}
}else{
	switch ($to) {
		case 'login':
			include"php/login.php";
			break;
		default:
			include"page/beforeLogin.php";
			break;
	}
}

?>