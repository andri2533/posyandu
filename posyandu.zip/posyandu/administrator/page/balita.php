<?php include"header.php"; ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1 style="font-family: arial;">
								Data Bayi dan Balita
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-md-10">
								<table id="dbb" class="easyui-datagrid" 
									title="Data Bayi & Balita" singleSelect="true" style="width:850px;height:450px"
									url="<?= base_url('/json/?for=tabelAnakAdmin') ?>" rownumbers="true" pagination="true">
									<thead>
										<tr>
											<th data-options="field:'id_anak'	,width:'100'">ID</th>
											<th data-options="field:'nama_anak'	,width:'100'">Nama</th>
											<th data-options="field:'panjang_badan'	,width:'100'">Panjang Badan</th>
											<th data-options="field:'berat_badan'	,width:'100'">Berat Badan</th>
											<th data-options="field:'umur_anak'	,width:'100'">Umur</th>
											<th data-options="field:'jk'	,width:'72'">Kelamin</th>
											<th data-options="field:'ayah'	,width:'100'">Ayah</th>
											<th data-options="field:'ibu'		,width:'100'">Ibu</th>
										</tr>
									</thead>
								</table>
							    <div id="" style="padding-top: 10px; padding-left: 10px; background:#fafafa; height:50px; width:850px; border:1px solid #ccc;">
							        <a href="#" class="easyui-linkbutton tambah" id="dlgbuttons" plain="false" onclick="newDep();"><i class="glyphicon glyphicon-plus"></i>&nbsp;Tambah</a>
							        <a href="#" class="easyui-linkbutton edit" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-pencil"></i>&nbsp;Edit</a>
							        <a href="#" class="easyui-linkbutton hapus" plain="false" onclick="removeDep();"><i class="glyphicon glyphicon-trash"></i>&nbsp;Hapus</a>
							    </div>
							</div>

							<div id="dlg" class="easyui-window" data-options=""
								title="Bayi Baru Lahir" 
								style="width:350px;height:auto; padding:10px 20px; display: none; z-index: 10000;"
							     closed="true" buttons="#dlg-buttons">

							    <form id="fm" method="post" novalidate autocomplete="off">

							        <div class="fitem">
							            <label style="width: auto;">ID</label>
							            <input name="id_anak" type="text" class="easyui-validatebox" style="width: 100%;" >
							        </div>

							        <div class="fitem">
							            <label style="width: auto;">Nama Bayi</label>
							            <input name="nama1" type="text" class="easyui-validatebox" style="width: 100%;" >
							            <input name="id_before" type="hidden" class="easyui-validatebox" style="width: 100%;" >
							        </div>

							        <div class="fitem">
							            <label style="width: auto;">Tanggal Lahir</label>
							            <input name="tanggal_lahir" type="date" class="easyui-validatebox" style="width: 100%;" >
							        </div>

							        <div class="fitem">
							            <label style="width: auto;">Panjang & Berat Badan</label>
							            <table>
							            	<tr>
							            		<td>
										            <input name="panjang" type="text" placeholder="Panjang Badan (Cm)" class="easyui-validatebox" style="width: 95%;" >
							            		</td>
							            		<td>
										            <input name="berat" type="text" placeholder="Berat Badan (Kg)" class="easyui-validatebox" style="width: 100%;" >
							            		</td>
							            	</tr>
							            </table>
							        </div>
							        <div class="fitem">
							            <label style="width: auto;">Jenis Kelamin</label><br>
							            <input name="jk" type="radio" value="1" required class="easyui-validatebox"> Laki - Laki
							            <input name="jk" type="radio" value="0" required class="easyui-validatebox">	Perempuan
							        </div>

							            <br>
							        <div class="fitem f_triger">
							            <label style="width: auto;">Informasi Orang Tua</label>
							            <br>
									 	<select name="triger" style="width: 100%; height: 35px;">
									 		<option value="0">Belum Pernah Daftar</option>
									 		<option value="1">Sudah Pernah Daftar</option>
									 	</select>
							        </div>
							        <div class="fitem f_ayah">
							        <br>
							            <table>
							            	<tr>
							            		<td>
										            <input name="ayah" type="text" placeholder="Ayah" class="easyui-validatebox" style="width:95%;" >
							            		</td>
							            		<td>
										            <input name="ibu" type="text" placeholder="Ibu" class="easyui-validatebox" style="width:100%;" >
							            		</td>
							            	</tr>
							            </table>
							        </div>
							        <div class="fitem f_ibu">
							            <label style="width: auto;">Alamat</label>
							            <textarea name="alamat" type="text" class="easyui-validatebox" style="width: 100%;" ></textarea>
							        </div>
							        <div class="fitem search_ortu" style="display: none;">
							            <label style="width: auto;"><br>Nama Orang Tua</label>
									 	<select name="id_ortu" style="width: 96%; height: 35px; border: 1px solid #eee; outline: none;">
									 	<option value="">--Orang Tua--</option>
									 	<?php
									 	$ortu=selectTable("SELECT * FROM t_ortu ",'array');
									 	foreach ($ortu as $row) { ?>
									 		<option value="<?= $row['id_ortu'] ?>"><?= $row['ayah']." & ".$row['ibu'] ?></option>
									 	<?php } ?>
									 	</select>
									 </div>

									</br>
							        <div class="ftitle" style="display: none;"></div>
							        <div id="dlg-buttons">
							            <a href="#" class="easyui-linkbutton submit simpan" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							            <a href="#" class="easyui-linkbutton submit update" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Update</a>
							        </div>
							    </form>
							</div>
						</div>
						<!-- /.row -->

					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
<script type="text/javascript">
	$(document).ready(function() {

		$("select[name=triger]").change(function(){
			if($(this).val()==1){
				$(".f_ayah, .f_ibu").slideUp();
				$(".search_ortu").slideDown();
			}else{
				$(".f_ayah, .f_ibu").slideDown();
				$(".search_ortu").slideUp();
			}
			// alert($(this).val())
		});

		function alertToInput(name){
			$("input[name='"+name+"']").css({
				"box-shadow":"0px 0px 3px red"
			});
			$("input[name='"+name+"']").focus();
			setTimeout(function(){
				$("input[name='"+name+"']").css({
					"box-shadow":"0px 0px 0px transparent"
				});
			}, 2000);
		}

		function update(){
			$(".update").click(function(event) {
				$.post('<?= base_url() ?>/register_submit', $("#fm").serialize(), function(data, textStatus, xhr) {
					if(data=="Sukses"){
						document.location="";
					}else{
						alert(data);
					}
				});

			});
		}
		update();

		function simpan(){
			$(".simpan").click(function(event) {
				var jk		 = '';
				var nama1	 = $("input[name='nama1']").val();
				var nama2	 = $("input[name='nama2']").val();
				var berat	 = $("input[name='berat']").val();
				var panjang	 = $("input[name='panjang']").val();
				jk			 = $("input[name='jk']:checked").val();
				var ayah	 = $("input[name='ayah']").val();
				var ibu	 	 = $("input[name='ibu']").val();
				var alamat 	 = $("textarea[name='alamat']").val();
				var triger 	 = $("select[name='triger']").val();
				var id_ortu	 = $("select[name='id_ortu']").val();

				if(nama1==''){
					alertToInput("nama1");
					return false;
				}else if(panjang==''){
					alertToInput("panjang");
					return false;
				}else if(berat==''){
					alertToInput("berat");
					return false;
				}else if(jk==''){
					alertToInput("jk");
					return false;
				}
				// if(triger==0){
				// 	if(ayah==''){
				// 		alertToInput("ayah");
				// 		return false;
				// 	}else if(ibu==''){
				// 		alertToInput("ibu");
				// 		return false;
				// 	}
				// }else if(triger==1){
				// 	if(id_ortu==''){
				// 		// alertToInput("cari_ortu");
				// 		$("select[name=id_ortu]").css({
				// 			"box-shadow":"0px 0px 1px red"
				// 		});
				// 		return false;
				// 	}
				// }
				$.post('<?= base_url("/register_submit") ?>', $("#fm").serialize(), function(data, textStatus, xhr) {
					if(data=="Sukses"){
						document.location="";
						// alert(data);
					}else{
						alert(data);
					}
				});

				return false;
			});
		}
		simpan();
	}); //<!--JQuery-->

	// EasyUi
	function newDep(){
		$(".simpan").show();
		$(".update").hide();
		$("input[name=id_anak]").val('');
		$("input[name=nama1]").val('');
		$("input[name=panjang]").val('');
		$("input[name=berat]").val('');
		$("input[name=tanggal_lahir]").val('');
		$("input[name=jk]").attr('checked', false);;
		$("#dlg .panel, .window").fadeIn();
		$(".f_ayah").show();
		$(".f_ibu").show();
		$(".f_triger").show();
	}

	var dataAnak=[];
	var indek=0;
	function editDep(){
		$(".update").show();
		$(".simpan").hide();
		if(indek==0){
			return false;
		}else{
			$("input[name=id_before]").val(dataAnak.id_anak);
			$("input[name=id_anak]").val(dataAnak.id_anak);
			$("input[name=nama1]").val(dataAnak.nama_anak);
			$("input[name=panjang]").val(dataAnak.panjang_badan.replace(' Cm',''));
			$("input[name=berat]").val(dataAnak.berat_badan.replace(' Kg',''));
			$("input[name=tanggal_lahir]").val(dataAnak.tanggal_lahir);
			if(dataAnak.jk=='L'){
				$("input[name=jk][value=1]").attr('checked', true);
			}else{
				$("input[name=jk][value=0]").attr('checked', true);
			}
			$("#dlg .panel, .window").fadeIn();
			$(".f_ayah").hide();
			$(".f_ibu").hide();
			$(".f_triger").hide();
		}
	}
	$("#dbb").datagrid({
		onClickRow:function(index, row){
			indek=index+1;
			dataAnak=row;
			// alert(row.jk)
		}
	});

    function removeDep(){
    	if(indek==0){
    		alert("Tidak ada data yang di hapus.");
    	}else{
	    	var x = confirm("Yakin, Data akan di hapus ?");
	    	if(x){
	    		$.get('<?= base_url() ?>/register_submit/?id_anak='+dataAnak.id_anak, function(data) {
	    			if(data=="Sukses"){
						document.location="";
	    			}else{
	    				alert(data);
	    			}
	    		});
	    	}else{
	    		// tidak jadi hapus data
	    	}
	    }
    	return false;
    }

    function alertUi(){
		$.messager.confirm("Asas","aasdasd",function(){
		});
    }
</script>
<?php include"footer.php"; ?>
