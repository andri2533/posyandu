<?php include"header.php"; ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1 style="font-family: arial;">
								Home
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-md-6">
								<table id="tb1"></table>
							</div>
							<div class="col-md-6">
								<table id="tb2" class="easyui-datagrid" 
									title="Data Bayi Setiap Bulan"
									singleSelect="true"
									style="width:545px;height:300px"
									showFooter="true"
									url=""
									rownumbers="true" pagination="true">
									<thead>
										<tr>
											<th data-options="field:'tanggal_timbang',width:'80'">Tanggal</th>
											<th data-options="field:'umur_anak',width:'100'">Umur</th>
											<th data-options="field:'berat_badan',width:'80'">Berat Badan</th>
											<th data-options="field:'panjang_badan',width:'100'">Panjang Badan</th>
											<th data-options="field:'imunisasi',width:'70'">Imunisasi</th>
											<th data-options="field:'vitamin',width:'67'">Vitamin</th>
										</tr>
									</thead>
								</table>
							    <div id="" style="padding-top: 10px; padding-left: 10px; background:#fafafa; height:50px; width:545px; border:1px solid #ccc;">
							        <a href="#" class="easyui-linkbutton tambah" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-plus"></i>&nbsp;add</a>
							        <a href="#" class="easyui-linkbutton edit" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-pencil"></i>&nbsp;Edit</a>
							        <a href="#" class="easyui-linkbutton hapus" plain="false" onclick="removeDep();"><i class="glyphicon glyphicon-trash"></i>&nbsp;Hapus</a>
							    </div>
							</div>
							<div id="dlg" class="easyui-dialog" data-options=""
								title="Update Data" 
								style="width:350px;height:auto;padding:10px 20px; display: none;"
							     closed="true" buttons="#dlg-buttons">

							    <form id="fm" method="post" novalidate autocomplete="off">
							        <div class="fitem f_usia">
							            <label style="width: auto;">Umur :</label>
							            <input name="umur" type="text" class="easyui-validatebox" style="width:100%;" >
							            <input name="id_laporan" type="hidden" class="easyui-validatebox" style="width:100%;" >
							        </div>
							        <br>
							        <div class="fitem f_Usia">
							        	<table>
							        		<tr>
							        			<td>
										            <label style="width: auto;">Berat Badan</label>
										            <input name="id_anak" type="hidden" class="easyui-validatebox" style="width:95%;" >
										            <input name="id_laporan" type="hidden" class="easyui-validatebox" style="width:95%;" >
										            <input name="berat" type="text" placeholder="Kg" class="easyui-validatebox" style="width:95%;" >
							        			</td>
							        			<td>
										            <label style="width: auto;">Panjang Badan</label>
										            <input name="panjang" type="text" placeholder="Cm" class="easyui-validatebox" style="width:100%;" >
							        			</td>
							        		</tr>
							        		<tr>
							        			<td colspan="2" >&nbsp;</td>
							        		</tr>
							        		<tr>
							        			<td>
										            <label style="width: auto;">Imunisasi</label>
										            <input name="imunisasi" type="text" class="easyui-validatebox" style="width:95%;" >
							        			</td>
							        			<td>
										            <label style="width: auto;">Vitamin</label>
										            <input name="vitamin" type="text" class="easyui-validatebox" style="width:100%;" >
							        			</td>
							        		</tr>
							        	</table>
							        </div>
							        <div class="f_item tanggal_timbang" style="display: none;">
							        	<label style="widh: auto;">Tanggal Timbang</label>
							        	<input name="tanggal_timbang" type="date" style="width: 100%;">
							        </div>
							        <div class="ftitle" style="display: none;"></div>
							        <div id="dlg-buttons">
							            <a href="#" class="easyui-linkbutton submit simpan" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							            <a href="#" class="easyui-linkbutton submit update" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							        </div>
							    </form>
							</div>
						</div>
						<!-- /.row -->

					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
<script type="text/javascript">
		function loadtb(){
			$("#tb1").datagrid({
				url:"<?= sendToApp('tbAfterLogin') ?>",
				width:'545px',
				height:'350px',
				title:'Data Bayi & Balita',
				pagination:'true',
				singleSelect:'true',
				rownumbers:'true',
				columns: [[
					{field:"nama_anak", sortable: true, title: "Nama", width:120},
					{field:"tanggal_lahir", sortable: true, title: "Tanggal Lahir", width:100},
					{field:"umur_anak", title: "Umur", width:87},
					{field:"jk", title: "Kelamin", width:65},
					{field:"ibu", title: "Ibu", width:70},
					{field:"ayah", title: "Ayah", width:70}
				]],
				onClickRow:function(index, row){
					var nama_anak=row.nama_anak;
					var id_anak=row.id_anak;
					$("#tb2").datagrid({
						url:"<?= sendToApp('tbAfterLogin&action=tb2') ?>&id_anak="+id_anak,
						title:"Kedatangan "+nama_anak+" Ke Posyandu"
					});

					// $(".easyui-linkbutton").css({
					// 	"background":"#D5D5D5",
					// 	"border-color":"#D5D5D5",
					// })
				}
			});
		}
		loadtb();

		// $("#tb1").datagrid({
		// 	title:"asas"
		// })
</script>
<script type="text/javascript">
	$(function(){
		var ortu=[];
		var anak=[];
		$("#tb2").datagrid({
			onClickRow:function(index, row){
				ortu=row;
				// alert(ortu.id_laporan);
			}
		});

		$(".hapus").click(function(){
			if(ortu.id_laporan){
				$.messager.confirm('Konfirmasi', 'Data Akan di hapus ?', function(a){
					if(a){
						// alert('data di haspus');
						$.post('<?= sendToApp("tbAfterLogin&action=delete&id_laporan=") ?>'+ortu.id_laporan, function(data, textStatus, xhr) {
							if(data=="Sukses"){
								// window.location="";
								$("#dlg").dialog('close');
								alertSucces('Data berhasil di hapus');
							}else{
								alert(data);
							}
						});
					}
				});
			}

			return false;
		});

		function alertSucces(pesan){
	        $.messager.show({  
	            title:'Success',  
	            msg:pesan,  
	            showType:'fade',
	            timeout:1000,                     
	            style:{  
	                right:'',  
	                bottom:''  
	            }
	        });
	        ortu=[];
	        anak=[];
			$("#tb1").datagrid('reload');
			$("#tb2").datagrid('reload');
		}


		$(".edit").click(function(event) {
			if(ortu.id_laporan){
				$(".update").show();
				$(".simpan").hide();
				$(".tanggal_timbang").hide();
				$("input[name=tanggal_timbang]").val('');
				$("input[name=id_anak]").val('');
				$("input[name=id_laporan]").val(ortu.id_laporan);
				$("input[name=umur]").val(ortu.umur_anak.replace(' Bulan',''));
				$("input[name=berat]").val(ortu.berat_badan.replace(' Kg',''));
				$("input[name=panjang]").val(ortu.panjang_badan.replace(' Cm',''));
				$("input[name=imunisasi]").val(ortu.imunisasi);
				$("input[name=vitamin]").val(ortu.vitamin);
				$("input[name=umur]").focus();
				$("#dlg").dialog({
					title:"Edit data"
				});
				$("#dlg").dialog('open');
			}else{
				
			}
			return false;
		});
		$(".update").click(function(){
			$.post('<?= sendToApp("tbAfterLogin&action=update") ?>', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=="Sukses"){
					$("#dlg").dialog('close');
					alertSucces('Data berhasil di update');
				}else{
					alert(data);
				}
			});

			return false;
		});


		$(".tambah").click(function(event) {
			anak=$("#tb1").datagrid('getSelected');
			if(anak.id_anak){
				$(".update").hide();
				$(".simpan").show();
				$(".tanggal_timbang").show();
				$("input[name=tanggal_timbang]").val('');
				$("input[name=id_anak]").val(anak.id_anak);
				$("input[name=id_laporan]").val('');
				$("input[name=umur]").val('');
				$("input[name=berat]").val('');
				$("input[name=panjang]").val('');
				$("input[name=imunisasi]").val('');
				$("input[name=vitamin]").val('');
				$("input[name=umur]").focus();
				$("#dlg").dialog({
					title:"Tambah data"
				});
				$("#dlg").dialog('open');
			}
			return false;
		});
		$(".simpan").click(function(event) {
			if($("input[name=ayah]").val()==''){
				$("input[name=ayah]").focus();
				return false;
			}else if($("input[name=ibu]").val()==''){
				$("input[name=ibu]").focus();
				return false;
			}else if($("textarea[name=alamat]").val()==''){
				$("textarea[name=alamat]").focus();
				return false;
			}
			$.post('<?= sendToApp() ?>tbAfterLogin&action=add', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=='Sukses'){
					$("#dlg").dialog('close');
					alertSucces('Data berhasil di simpan');
				}else{
					alert(data);
				}
			});

			return false;
		});
	});
</script>
<?php include"footer.php"; ?>
