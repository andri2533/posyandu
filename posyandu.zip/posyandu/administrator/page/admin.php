<?php include"header.php"; ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1 style="font-family: arial;">
								Data Orang Tua
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-md-10">
								<table id="dbb" class="easyui-datagrid" 
									title="Data Admin" singleSelect="true" style="width:370px;height:300px"
									url="<?= sendToApp('tbAdmin') ?>" rownumbers="true" pagination="true">
									<thead>
										<tr>
											<th data-options="field:'username',width:'100'">Username</th>
											<th data-options="field:'level',width:'50'">Level</th>
											<th data-options="field:'password',width:'170'">Password</th>
										</tr>
									</thead>
								</table>
							    <div id="" style="padding-top: 10px; padding-left: 10px; background:#fafafa; height:50px; width:370px; border:1px solid #ccc;">
							        <a href="#" class="easyui-linkbutton tambah" id="dlgbuttons" plain="false" onclick="tambah();"><i class="glyphicon glyphicon-plus"></i>&nbsp;Tambah</a>
							        <a href="#" class="easyui-linkbutton edit" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-pencil"></i>&nbsp;Edit</a>
							        <a href="#" class="easyui-linkbutton hapus" plain="false" onclick="removeDep();"><i class="glyphicon glyphicon-trash"></i>&nbsp;Hapus</a>
							    </div>
							</div>
							<div id="dlg" class="easyui-dialog" data-options=""
								title="Tambah Admin" 
								style="width:350px;height:auto;padding:10px 20px; display: none;"
							     closed="true" buttons="#dlg-buttons">

							    <form id="fm" method="post" novalidate autocomplete="off">
							        <div class="fitem f_username">
							            <label style="width: auto;">Username :</label>
							            <input name="username" type="text" class="easyui-validatebox" style="width:100%;" >
							            <input name="id_admin" type="hidden" class="easyui-validatebox" style="width:100%;" >
							        </div>
							        <div class="fitem f_username">
							            <label style="width: auto;">Password :</label>
							            <input name="password" type="password" class="easyui-validatebox" style="width:100%;" >
							        </div>
							        <div class="fitem f_password">
							            <label style="width: auto;">Level :</label>
							            <input name="level" type="number" class="easyui-validatebox" style="width: 100%;" />
							        </div>
									</br>
							        <div class="ftitle" style="display: none;"></div>
							        <div id="dlg-buttons">
							            <a href="#" class="easyui-linkbutton submit simpan" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							            <a href="#" class="easyui-linkbutton submit update" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							        </div>
							    </form>
							</div>
						</div>
						<!-- /.row -->

					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
<script type="text/javascript">
	$(function(){
		var ortu=[];
		$("#dbb").datagrid({
			onClickRow:function(index, row){
				ortu=row;
			}
		});

		$(".tambah").click(function(event) {
			$(".update").hide();
			$(".simpan").show();
			$("#dlg").dialog('open');
			$("input[name=username]").val('');
			$("input[name=password]").val('');
			$("input[name=level]").val('');
			$("input[name=id_admin]").val('');
			$("input[name=username]").focus();

			return false;
		});

		$(".edit").click(function(event) {
			if(ortu.id_admin){
				$(".update").show();
				$(".simpan").hide();
				$("input[name=username]").val(ortu.username);
				$("input[name=password]").val(ortu.password);
				$("input[name=level]").val(ortu.level);
				$("input[name=id_admin]").val(ortu.id_admin);
				$("input[name=username]").focus();
				$("#dlg").dialog('open');
			}else{
				
			}
			return false;
		});

		$(".hapus").click(function(){
			if(ortu.id_admin){
				$.messager.confirm('Konfirmasi', 'Data Akan di hapus ?', function(a){
					if(a){
						// alert('data di haspus');
						$.post('<?= sendToApp("tbAdmin&action=delete&id_admin=") ?>'+ortu.id_admin, function(data, textStatus, xhr) {
							if(data=="Sukses"){
								alertSucces("Data berhasil di hapus");
							}else{
								alert(data);
							}
						});
					}
				});
			}

			return false;
		});

		$(".update").click(function(){
			$.post('<?= sendToApp("tbAdmin&action=update") ?>', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=="Sukses"){
					alertSucces("Data berhasil di simpan");
				}else{
					alert(data);
				}
			});

			return false;
		});

		$(".simpan").click(function(event) {
			if($("input[name=username]").val()==''){
				$("input[name=username]").focus();
				return false;
			}else if($("input[name=password]").val()==''){
				$("input[name=password]").focus();
				return false;
			}else if($("input[name=level]").val()==''){
				$("input[name=level]").focus();
				return false;
			}
			$.post('<?= sendToApp() ?>tbAdmin&action=add', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=='Sukses'){
					alertSucces("Data berhasil di simpan");
				}else{
					alert(data);
				}
			});

			return false;
		});


		function alertSucces(pesan){
			$("#dlg").dialog('close');
	        $.messager.show({  
	            title:'Success',  
	            msg:pesan,  
	            showType:'fade',
	            timeout:1000,                     
	            style:{  
	                right:'',  
	                bottom:''  
	            }
	        });
	        ortu=[];
			$("#dbb").datagrid('reload');
		}
	});
</script>
<?php include"footer.php"; ?>
