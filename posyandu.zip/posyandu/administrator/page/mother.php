<?php include"header.php"; ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1 style="font-family: arial;">
								Home
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-md-4">
								<table id="tb1"></table>
							</div>
							<div class="col-md-8">
								<table id="tb2" class="easyui-datagrid" 
									title="Data Bayi Setiap Bulan"
									singleSelect="true"
									style="width:581px;height:316px; margin-left: 100px;"
									showFooter="true"
									url=""
									rownumbers="true" pagination="true">
									<thead>
										<tr>
											<th data-options="field:'tanggal_timbang',width:'80'">Tanggal</th>
											<th data-options="field:'berat_badan',width:'80'">Berat Badan</th>
											<th data-options="field:'lingkar_lengan',width:'120'">Lingkar Lengan (LK)</th>
											<th data-options="field:'lingkar_pinggang',width:'130'">Lingkar Pinggang (LP)</th>
											<th data-options="field:'tinggi_badan',width:'120'">Tinggi Badan (TB)</th>
										</tr>
									</thead>
								</table>
							    <div id="" style="padding-top: 10px; padding-left: 10px; background:#fafafa; height:50px; width:581px; border:1px solid #ccc;">
							        <a href="#" class="easyui-linkbutton tambah" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-plus"></i>&nbsp;add</a>
							        <a href="#" class="easyui-linkbutton edit" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-pencil"></i>&nbsp;Edit</a>
							        <a href="#" class="easyui-linkbutton hapus" plain="false" onclick="removeDep();"><i class="glyphicon glyphicon-trash"></i>&nbsp;Hapus</a>
							    </div>
							</div>
							<div id="dlg" class="easyui-dialog"
								style="width:350px;height:auto;padding:10px 20px; display: none;"
							     closed="true" buttons="#dlg-buttons">

							    <form id="fm" method="post" novalidate autocomplete="off">
							        <div class="fitem f_Usia">
							        	<table>
							        		<tr>
							        			<td>
										            <label style="width: auto;">Berat Badan</label>
										            <input name="id_ortu" type="hidden" class="easyui-validatebox" style="width:95%;" >
										            <input name="id_laporan" type="hidden" class="easyui-validatebox" style="width:95%;" >
										            <input name="berat" type="text" placeholder="Kg" class="easyui-validatebox" style="width:95%;" >
							        			</td>
							        			<td>
										            <label style="width: auto;">Lingkar Lengan (LK)</label>
										            <input name="lingkar_lengan" type="text" placeholder="Cm" class="easyui-validatebox" style="width:100%;" >
							        			</td>
							        		</tr>
							        		<tr>
							        			<td colspan="2" >&nbsp;</td>
							        		</tr>
							        		<tr>
							        			<td>
										            <label style="width: auto;">Lingkar Pinggang (LP)</label>
										            <input name="lingkar_pinggang" type="text" placeholder="Cm" class="easyui-validatebox" style="width:95%;" >
							        			</td>
							        			<td>
										            <label style="width: auto;">Tinggi Badan</label>
										            <input name="tinggi_badan" type="text" placeholder="Cm" class="easyui-validatebox" style="width:100%;" >
							        			</td>
							        		</tr>
							        	</table>
							        </div>
							        <div class="ftitle" style="display: none;"></div>
							        <div id="dlg-buttons">
							            <a href="#" class="easyui-linkbutton submit simpan" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							            <a href="#" class="easyui-linkbutton submit update" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							        </div>
							    </form>
							</div>
						</div>
						<!-- /.row -->

					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
<script type="text/javascript">
		function loadtb(){
			$("#tb1").datagrid({
				url:"<?= sendToApp('tbMother') ?>",
				width:'350px',
				height:'366px',
				title:'Data Ibu',
				pagination:'true',
				singleSelect:'true',
				rownumbers:'true',
				columns: [[
					// {field:"nama_anak", title: "Nama", width:120},
					// {field:"umur_anak", title: "Umur", width:100},
					// {field:"jk", title: "Kelamin", width:70},
					{field:"ibu", title: "Ibu", sortable:true, width:100},
					{field:"ayah", title: "Ayah", width:100},
					{field:"tanggal_masuk", title: "Tanggal Masuk", sortable: true, width:117}
				]],
				onClickRow:function(index, row){
					var ibu=row.ibu;
					var id_ortu=row.id_ortu;
					$("#tb2").datagrid({
						url:"<?= sendToApp('tbMother&action=get&id_ortu=') ?>"+id_ortu,
						title:"Kedatangan "+ibu+" Ke Posyandu"
					});

					// $(".easyui-linkbutton").css({
					// 	"background":"#D5D5D5",
					// 	"border-color":"#D5D5D5",
					// })
				}
			});
		}
		loadtb();

		// $("#tb1").datagrid({
		// 	title:"asas"
		// })
</script>
<script type="text/javascript">
	$(function(){
		var ortu=[];
		var anak=[];
		$("#tb2").datagrid({
			onClickRow:function(index, row){
				ortu=row;
			}
		});

		$(".hapus").click(function(){
			if(ortu.id_laporan){
				$.messager.confirm('Konfirmasi', 'Data Akan di hapus ?', function(a){
					if(a){
						// alert('data di haspus');
						$.post('<?= sendToApp("tbMother&action=delete&id_laporan=") ?>'+ortu.id_laporan, function(data, textStatus, xhr) {
							if(data=="Sukses"){
								// window.location="";
								$("#dlg").dialog('close');
								alertSucces('Data berhasil di hapus');
							}else{
								alert(data);
							}
						});
					}
				});
			}

			return false;
		});

		function alertSucces(pesan){
	        $.messager.show({  
	            title:'Success',  
	            msg:pesan,  
	            showType:'fade',
	            timeout:1000,                     
	            style:{  
	                right:'',  
	                bottom:''  
	            }
	        });
	        ortu=[];
	        anak=[];
			$("#tb1").datagrid('reload');
			$("#tb2").datagrid('reload');
		}


		$(".edit").click(function(event) {
			if(ortu.id_laporan){
				$(".update").show();
				$(".simpan").hide();
				$("input[name=id_ortu]").val('');
				$("input[name=id_laporan]").val(ortu.id_laporan);
				$("input[name=berat]").val(ortu.berat_badan.replace(" Kg",''));
				$("input[name=lingkar_lengan]").val(ortu.lingkar_lengan.replace(" Cm",''));
				$("input[name=lingkar_pinggang]").val(ortu.lingkar_pinggang.replace(" Cm",''));
				$("input[name=tinggi_badan]").val(ortu.tinggi_badan.replace(" Cm",''));
				$("#dlg").dialog('open');
				$("input[name=berat]").focus();
			}else{
				
			}
			return false;
		});
		$(".update").click(function(){
			$.post('<?= sendToApp("tbMother&action=update") ?>', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=="Sukses"){
					$("#dlg").dialog('close');
					alertSucces('Data berhasil di update');
				}else{
					alert(data);
				}
			});

			return false;
		});


		$(".tambah").click(function(event) {
			ortu=$("#tb1").datagrid('getSelected');
			if(ortu.id_ortu){
				$(".update").hide();
				$(".simpan").show();
				$("input[name=id_ortu]").val(ortu.id_ortu);
				$("input[name=id_laporan]").val('');
				$("input[name=berat]").val('');
				$("input[name=lingkar_lengan]").val('');
				$("input[name=lingkar_pinggang]").val('');
				$("input[name=tinggi_badan]").val('');
				$("#dlg").dialog('open');
				$("input[name=berat]").focus();
			}
			return false;
		});
		$(".simpan").click(function(event) {
			$.post('<?= sendToApp() ?>tbMother&action=add', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=='Sukses'){
					$("#dlg").dialog('close');
					alertSucces('Data berhasil di simpan');
				}else{
					alert(data);
				}
			});

			return false;
		});
	});
</script>
<?php include"footer.php"; ?>
