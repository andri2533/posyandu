<?php include"header.php" ?>
<script src="<?= base_url() ?>/js/code/highcharts.js" type="text/javascript"></script>
<script src="<?= base_url() ?>/js/code/modules/exporting.js" type="text/javascript"></script>
<script>
// line biasa
$(function () {
    $("#fm").submit(function(){
       $.post('<?= sendToApp("tbGrafik") ?>', $(this).serialize(), function(data, textStatus, xhr) {
            if(data=='Gagal update.'){
                alert(data);
            }else{
                window.location='';
                // alert(data);
                // var refresh= $("#container").Highcharts();
                // refresh.redraw();
            }
        });

       return false;
    });

    $(".simpan").click(function(){
       $.post('<?= sendToApp("tbGrafik") ?>', $("#fm").serialize(), function(data, textStatus, xhr) {
            if(data=='Gagal update.'){
                alert(data);
            }else{
                window.location='';
                // alert(data);
                // var refresh= $("#container").Highcharts();
                // refresh.redraw();
            }
        });

       return false;
    })

    $(document).keydown(function(event) {
        if(event.which==27){ //keyboard ESC
            $(".highcharts-reset-zoom").click();
        }
    });

    Highcharts.chart('container', {
        chart: {
            type: 'areaspline',
            zoomType:'xy'
        },
        title: {
            text: 'Grafik Berat Badan Bayi & Balita'
        },
        xAxis: {
            categories: <?= json_encode($categori) ?>,
            gridLineWidth: 1,
            gridZIndex: 10,
            gridLineColor: "#bbb"
            // plotBands: [{ // visualize the weekend
            //     from: 4.5,
            //     to: 6.5,
            //     color: 'rgba(68, 170, 213, .2)'
            // }]
        },
        yAxis: {
            labels:{
                formatter: function(){
                    return this.value + ' Kg';
                }
            },
            title: {
                text: '<p style="font-size: 17px;">Berat Kg</p>'
            },
            gridLineWidth: 1,
            gridZIndex: 20,
            gridLineColor: "#bbb"
        },
        tooltip: {
            shared: false,
            valueSuffix: ' Kg',
            backgroundColor: '#bbb',
            useHTML: true,
            style:{
                padding:100
            }
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 1
                // opacity background area
            },
            series:{
                cursor:'pointer',
                // allowPointSelect: true,
                point:{
                    events:{
                        click:function(event){
                            var batas= this.series.name;
                            var usia= this.category;
                            var isi = this.y;

                            $("input[name=batas]").val(batas);
                            $("input[name=usia]").val(usia);
                            $("input[name=isi]").val(isi);
                            $("#dlg").dialog({
                                title:usia+" Bulan"
                            });
                            $("#dlg").dialog('open');
                            $("input[name=isi]").focus();
                            // alert(this.category);
                        }
                    }
                }
            }
        },
        series: [{
                name: 'Batas Atas',
                data: <?= json_encode($batasAtas); ?>,
                color : "#DCFE3D",
                lineColor:"#555",
                dataLabels: {
                    enabled: true
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
            },{
                name: 'Batas Atas 2',
                data: <?= json_encode($batasAtas2); ?>,
                color : "#0DFF00",
                lineColor:"#555",
                dataLabels: {
                    enabled: true
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
            },{
                name: 'Batas Atas 3',
                data: <?= json_encode($batasAtas3); ?>,
                color : "#09B400",
                lineColor:"#555",
                dataLabels: {
                    enabled: true
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
            },{
                name: 'center',
                data: <?= json_encode($center); ?>,
                color : "#09B400",
                lineColor:"#555",
                dataLabels: {
                    enabled: true
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
            },{
                name: 'Batas Bawah 3',
                data: <?= json_encode($batasBawah3); ?>,
                color : "#0DFF00",
                lineColor:"#555",
                dataLabels: {
                    enabled: true
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
            },{
                name: 'Batas Bawah 2',
                data: <?= json_encode($batasBawah2); ?>,
                color : "#DCFE3D",
                lineColor:"#555",
                dataLabels: {
                    enabled: true,
                    labelsZIndex: 100
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
                // color : "#A9FE75"
            },{
                name: 'Batas Bawah',
                data: <?= json_encode($batasBawah); ?>,
                color : "#fff",
                lineColor:"#555",
                dataLabels: {
                    enabled: true
                },
                marker: {
                    fillColor: 'white',
                    lineWidth: 1,
                    // lineColor: Highcharts.getOptions().colors[0]
                },
                lineWidth: 1
                // color : "#A9FE75"
            }
        ]
    });
});

// untuk input data
// $(function () {
//     Highcharts.chart('container', {
//         chart: {
//             type: 'scatter',
//             margin: [70, 50, 60, 80],
//             events: {
//                 click: function (e) {
//                     // find the clicked values and the series
//                     var x = Math.round(e.xAxis[0].value),
//                         y = e.yAxis[0].value,
//                         series = this.series[0];

//                     // Add it
//                     series.addPoint([x, y]);

//                 },
//                 mousemove:function(e){
//                     alert(e);
//                 }
//             }
//         },
//         title: {
//             text: 'User supplied data'
//         },
//         subtitle: {
//             text: 'Click the plot area to add a point. Click a point to remove it.'
//         },
//         xAxis: {
//             gridLineWidth: 1,
//             minPadding: 0.2,
//             maxPadding: 0.2,
//             maxZoom: 10,
//             min : 0,
//             tickInterval:1
//         },
//         yAxis: {
//             max:20,
//             min:0,
//             title: {
//                 text: 'Kg'
//             },
//             labels: {
//                 format: '{value} Kg'
//             },
//             minPadding: 0.2,
//             maxPadding: 0.2,
//             maxZoom: 25,
//             plotLines: [{
//                 value: 0,
//                 width: 1,
//                 color: '#808080'
//             }],
//             plotLines: [{
//                 color: 'red', // Color value
//                 dashStyle: 'longdashdot', // Style of the plot line. Default to solid
//                 value: 3, // Value of where the line will appear
//                 width: 2 // Width of the line    
//               }]
//         },
//         legend: {
//             enabled: false
//         },
//         exporting: {
//             enabled: false
//         },
//         plotOptions: {
//             series: {
//                 lineWidth: 1,
//                 point: {
//                     events: {
//                         'click': function () {
//                             if (this.series.data.length > 1) {
//                                 this.remove();
//                             }
//                         }
//                     }
//                 }
//             }
//         },
//         series: [
//         {
//             name:'Batas Atas',
//             data: [
//                 [0, 0]
//             ]
//         }
//         ]
//     });
// });
</script>
<style type="text/css">
    .higcharts-tooltip{
        z-index: 9999;
    }
</style>
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-content">
                <div class="page-header">
                    <h1 style="font-family: arial;">
                        Home
                    </h1>
                </div><!-- /.page-header -->

                <div class="container">
                    <div class="row">
                        <div class="col-md-1">&nbsp;</div>
                        <div class="col-md-11">
                            <center>
                                <div id="container" style="width: 100%; height: 600px; border: 0px solid red;"></div>
                                <?php if($page!=1){ ?>
                                    <a href="<?= base_url() ?>/administrator/mg/?p=<?= $page-1 ?>" title="">
                                        <span style="padding-right: 10px; padding-left: 10px; color: #eee; background: #09c;">
                                            <i class="fa fa-caret-left"></i>
                                        </span>
                                    </a>
                                <?php } ?>
                                <span>&nbsp;&nbsp;&nbsp;</span>
                                <?php if($limit>5){ ?>
                                <a href="<?= base_url() ?>/administrator/mg/" title="">
                                    <span style="padding-right: 10px; padding-left: 10px; color: #eee; background: #09c;">
                                        <i class="fa fa-zoom"><p>Back</p></i>
                                    </span>
                                </a>
                                <?php } ?>
                                <?php if($limit==5){ ?>
                                <a href="<?= base_url() ?>/administrator/mg/?i=100" title="">
                                    <span style="padding-right: 10px; padding-left: 10px; color: #eee; background: #09c;">
                                        <i class="fa fa-zoom"><p>View All</p></i>
                                    </span>
                                </a>
                                <?php } ?>
                                <span>&nbsp;&nbsp;&nbsp;</span>
                                <?php if( !isset($_GET['i']) AND $page<13){ ?>
                                <a href="<?= base_url() ?>/administrator/mg/?p=<?= $page+1 ?>" title="">
                                    <span style="padding-right: 10px; padding-left: 10px; color: #eee; background: #09c;">
                                        <i class="fa fa-caret-right"></i>
                                    </span>
                                </a>
                                <?php } ?>
                            </center>
                            <div id="dlg" class="easyui-dialog" data-options=""
                                title="Update Data" 
                                style="width:350px;height:auto;padding:10px 20px; display: none;"
                                 closed="true" buttons="#dlg-buttons">

                                <form id="fm" action="<?= sendToApp("tbGrafik") ?>" method="post" novalidate autocomplete="off">
                                    <div class="fitem f_ayah">
                                        <label style="width: auto;">Value :</label>
                                        <input name="isi" type="text" class="easyui-validatebox" style="width:100%;" >
                                        <input name="batas" type="hidden" class="easyui-validatebox" style="width:100%;" >
                                        <input name="usia" type="hidden" class="easyui-validatebox" style="width:100%;" >
                                    </div>
                                    <div class="ftitle" style="display: none;"></div>
                                    <div id="dlg-buttons">
                                        <a href="#" class="easyui-linkbutton submit simpan" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->
<?php include"footer.php"; ?>
