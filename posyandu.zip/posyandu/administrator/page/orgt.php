<?php include"header.php"; ?>
			<div class="main-content">
				<div class="main-content-inner">
					<div class="page-content">
						<div class="page-header">
							<h1 style="font-family: arial;">
								Data Orang Tua
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-md-10">
								<table id="dbb" class="easyui-datagrid" 
									title="Data Orang Tua Bayi / Balita" singleSelect="true" style="width:600px;height:390px"
									url="<?= sendToApp('tbOrgt') ?>" rownumbers="true" pagination="true">
									<thead>
										<tr>
											<th data-options="field:'ayah',width:'100'">Ayah</th>
											<th data-options="field:'ibu',width:'100'">Ibu</th>
											<th data-options="field:'alamat',width:'250'">Alamat</th>
											<th data-options="field:'tanggal_masuk',width:'100'">Tanggal Daftar</th>
										</tr>
									</thead>
								</table>
							    <div id="" style="padding-top: 10px; padding-left: 10px; background:#fafafa; height:50px; width:600px; border:1px solid #ccc;">
							        <a href="#" class="easyui-linkbutton tambah" id="dlgbuttons" plain="false" onclick="tambah();"><i class="glyphicon glyphicon-plus"></i>&nbsp;Tambah</a>
							        <a href="#" class="easyui-linkbutton edit" plain="false" onclick="editDep();"><i class="glyphicon glyphicon-pencil"></i>&nbsp;Edit</a>
							        <a href="#" class="easyui-linkbutton hapus" plain="false" onclick="removeDep();"><i class="glyphicon glyphicon-trash"></i>&nbsp;Hapus</a>
							    </div>
							</div>
							<div id="dlg" class="easyui-dialog" data-options=""
								title="Tambah Data Orang Tua" 
								style="width:350px;height:auto;padding:10px 20px; display: none;"
							     closed="true" buttons="#dlg-buttons">

							    <form id="fm" method="post" novalidate autocomplete="off">
							        <div class="fitem f_ayah">
							            <label style="width: auto;">Ayah :</label>
							            <input name="ayah" type="text" class="easyui-validatebox" style="width:100%;" >
							            <input name="id_ortu" type="hidden" class="easyui-validatebox" style="width:100%;" >
							        </div>
							        <div class="fitem f_ayah">
							            <label style="width: auto;">Ibu :</label>
							            <input name="ibu" type="text" class="easyui-validatebox" style="width:100%;" >
							        </div>
							        <div class="fitem f_ibu">
							            <label style="width: auto;">Alamat :</label>
							            <textarea name="alamat" type="text" class="easyui-validatebox" style="width: 100%;" ></textarea>
							        </div>
									</br>
							        <div class="ftitle" style="display: none;"></div>
							        <div id="dlg-buttons">
							            <a href="#" class="easyui-linkbutton submit simpan" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							            <a href="#" class="easyui-linkbutton submit update" plain="false" ><i class="glyphicon glyphicon-ok" ></i>&nbsp;Simpan</a>
							        </div>
							    </form>
							</div>
						</div>
						<!-- /.row -->

					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->
<script type="text/javascript">
	$(function(){
		var ortu=[];
		$("#dbb").datagrid({
			onClickRow:function(index, row){
				ortu=row;
			}
		});

		$(".tambah").click(function(event) {
			$(".update").hide();
			$(".simpan").show();
			$("#dlg").dialog('open');
			$("input[name=ayah]").val('');
			$("input[name=ibu]").val('');
			$("textarea[name=alamat]").val('');
			$("input[name=id_ortu]").val('');
			$("input[name=ayah]").focus();

			return false;
		});

		$(".edit").click(function(event) {
			if(ortu.id_ortu){
				$(".update").show();
				$(".simpan").hide();
				$("input[name=ayah]").val(ortu.ayah);
				$("input[name=ibu]").val(ortu.ibu);
				$("textarea[name=alamat]").val(ortu.alamat);
				$("input[name=id_ortu]").val(ortu.id_ortu);
				$("input[name=ayah]").focus();
				$("#dlg").dialog('open');
			}else{
				
			}
			return false;
		});

		$(".hapus").click(function(){
			if(ortu.id_ortu){
				$.messager.confirm('Konfirmasi', 'Data Akan di hapus ?', function(a){
					if(a){
						// alert('data di haspus');
						$.post('<?= sendToApp("tbOrgt&action=delete&id_ortu=") ?>'+ortu.id_ortu, function(data, textStatus, xhr) {
							if(data=="Sukses"){
								window.location="";
							}else{
								alert(data);
							}
						});
					}
				});
			}

			return false;
		});

		$(".update").click(function(){
			$.post('<?= sendToApp("tbOrgt&action=update") ?>', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=="Sukses"){
					window.location="";
				}else{
					alert(data);
				}
			});

			return false;
		});

		$(".simpan").click(function(event) {
			if($("input[name=ayah]").val()==''){
				$("input[name=ayah]").focus();
				return false;
			}else if($("input[name=ibu]").val()==''){
				$("input[name=ibu]").focus();
				return false;
			}else if($("textarea[name=alamat]").val()==''){
				$("textarea[name=alamat]").focus();
				return false;
			}
			$.post('<?= sendToApp() ?>tbOrgt&action=add', $("#fm").serialize(), function(data, textStatus, xhr) {
				if(data=='Sukses'){
					window.location='';
					// alert(data);
				}else{
					alert(data);
				}
			});

			return false;
		});
	});
</script>
<?php include"footer.php"; ?>
