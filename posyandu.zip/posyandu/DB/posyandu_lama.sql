-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2016 at 09:34 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `posyandu`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_anak`
--

CREATE TABLE `t_anak` (
  `id_anak` int(100) NOT NULL,
  `nama_anak` varchar(100) NOT NULL,
  `id_ortu` int(100) NOT NULL,
  `tanggal_masuk` datetime NOT NULL,
  `aktif` varchar(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_anak`
--

INSERT INTO `t_anak` (`id_anak`, `nama_anak`, `id_ortu`, `tanggal_masuk`, `aktif`) VALUES
(1, 'david', 1, '2016-11-16 00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `t_berat_badan`
--

CREATE TABLE `t_berat_badan` (
  `usia` varchar(4) NOT NULL,
  `bb_l` varchar(4) NOT NULL,
  `ba_l` varchar(4) NOT NULL,
  `bb_p` varchar(4) NOT NULL,
  `ba_p` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_laporan_anak`
--

CREATE TABLE `t_laporan_anak` (
  `id_laporan` int(100) NOT NULL,
  `id_anak` int(100) NOT NULL,
  `id_ortu` int(100) NOT NULL,
  `umur_anak` int(100) NOT NULL,
  `berat_anak` int(100) NOT NULL,
  `tanggal_timbang` datetime NOT NULL,
  `vitamin` varchar(100) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_laporan_ibu`
--

CREATE TABLE `t_laporan_ibu` (
  `id_laporan` int(100) NOT NULL,
  `id_ortu` int(100) NOT NULL,
  `berat_ibu` int(100) NOT NULL,
  `tanggal_timbang` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_ortu`
--

CREATE TABLE `t_ortu` (
  `id_ortu` int(100) NOT NULL,
  `ibu` varchar(100) NOT NULL,
  `ayah` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_ortu`
--

INSERT INTO `t_ortu` (`id_ortu`, `ibu`, `ayah`) VALUES
(1, 'mamik', 'budi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_anak`
--
ALTER TABLE `t_anak`
  ADD PRIMARY KEY (`id_anak`),
  ADD KEY `id_ortu` (`id_ortu`);

--
-- Indexes for table `t_berat_badan`
--
ALTER TABLE `t_berat_badan`
  ADD PRIMARY KEY (`usia`);

--
-- Indexes for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  ADD PRIMARY KEY (`id_laporan`),
  ADD KEY `id_anak` (`id_anak`),
  ADD KEY `id_ortu` (`id_ortu`);

--
-- Indexes for table `t_laporan_ibu`
--
ALTER TABLE `t_laporan_ibu`
  ADD PRIMARY KEY (`id_laporan`),
  ADD KEY `id_ortu` (`id_ortu`);

--
-- Indexes for table `t_ortu`
--
ALTER TABLE `t_ortu`
  ADD PRIMARY KEY (`id_ortu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_anak`
--
ALTER TABLE `t_anak`
  MODIFY `id_anak` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  MODIFY `id_laporan` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t_laporan_ibu`
--
ALTER TABLE `t_laporan_ibu`
  MODIFY `id_laporan` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t_ortu`
--
ALTER TABLE `t_ortu`
  MODIFY `id_ortu` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_anak`
--
ALTER TABLE `t_anak`
  ADD CONSTRAINT `t_anak_ibfk_1` FOREIGN KEY (`id_ortu`) REFERENCES `t_ortu` (`id_ortu`);

--
-- Constraints for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  ADD CONSTRAINT `t_laporan_anak_ibfk_1` FOREIGN KEY (`id_ortu`) REFERENCES `t_ortu` (`id_ortu`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `t_laporan_anak_ibfk_2` FOREIGN KEY (`id_anak`) REFERENCES `t_anak` (`id_anak`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
