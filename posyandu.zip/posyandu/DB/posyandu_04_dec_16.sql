-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2016 at 11:43 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `posyandu`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_admin`
--

CREATE TABLE `t_admin` (
  `id_admin` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `level` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_admin`
--

INSERT INTO `t_admin` (`id_admin`, `username`, `password`, `level`) VALUES
(1, 'root', '008', 1),
(6, 'sa', 'sa', 0);

-- --------------------------------------------------------

--
-- Table structure for table `t_anak`
--

CREATE TABLE `t_anak` (
  `id_anak` int(100) NOT NULL,
  `nama_anak` varchar(100) NOT NULL,
  `id_ortu` int(100) NOT NULL,
  `berat_badan` varchar(4) NOT NULL,
  `panjang_badan` varchar(4) NOT NULL,
  `tanggal_lahir` varchar(50) NOT NULL,
  `tanggal_masuk` datetime NOT NULL,
  `jk` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_anak`
--

INSERT INTO `t_anak` (`id_anak`, `nama_anak`, `id_ortu`, `berat_badan`, `panjang_badan`, `tanggal_lahir`, `tanggal_masuk`, `jk`) VALUES
(1, 'david', 1, '2.9', '10', '2016-09-25', '2016-11-16 00:00:00', '1'),
(2, 'dewi', 2, '3', '29', '2016-11-27', '2016-11-16 00:00:00', '0'),
(5, 'Ahmad Faris', 4, '4', '18', '2016-10-30', '2016-11-26 18:36:58', '1'),
(7, 'Andri Adi Susanto', 6, '8', '81', '2016-11-27', '2016-11-26 20:23:25', '1'),
(10, 'Ari Jalul', 6, '2.2', '20', '2016-11-01', '2016-11-26 21:33:11', '1'),
(11, 'Putri Sul', 9, '2', '12', '2016-11-01', '2016-11-28 20:27:21', '0'),
(12, 'Putra bin ngateman', 10, '4', '29', '2016-11-17', '2016-11-28 20:28:57', '1'),
(15, 'Bayu ', 13, '2.5', '14.3', '2016-11-30', '2016-12-01 12:08:15', '1'),
(21, 'Sueb ', 16, '2', '2', '2016-10-05', '2016-12-01 17:20:31', '1');

-- --------------------------------------------------------

--
-- Table structure for table `t_berat_badan`
--

CREATE TABLE `t_berat_badan` (
  `usia` int(4) NOT NULL,
  `bb_l` varchar(4) NOT NULL,
  `ba_l` varchar(4) NOT NULL,
  `bb_p` varchar(4) NOT NULL,
  `ba_p` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_berat_badan`
--

INSERT INTO `t_berat_badan` (`usia`, `bb_l`, `ba_l`, `bb_p`, `ba_p`) VALUES
(0, '2.5', '4.4', '2.4', '4.2'),
(1, '3.4', '5.8', '3.2', '5.5'),
(2, '4.3', '7.1', '3.9', '6.6'),
(3, '5.0', '8.0', '4.5', '7.5'),
(4, '5.6', '8.7', '5.0', '8.2'),
(6, '6.4', '9.8', '5.7', '9.3'),
(7, '6.7', '10.3', '6', '9.8'),
(8, '6.9', '10.7', '6.3', '10.2'),
(9, '7.1', '11.0', '6.5', '10.5'),
(10, '7.4', '11.0', '6.7', '10.9'),
(11, '7.6', '11.7', '6.9', '11.2'),
(12, '7.7', '12', '6.9', '11.5'),
(13, '7.9', '12.3', '7.2', '11.8'),
(14, '8.1', '12.6', '7.4', '12.1'),
(15, '8.3', '12.8', '7.6', '12.4'),
(16, '8.4', '13.1', '7.7', '12.6'),
(17, '8.6', '13.4', '7.9', '12.9'),
(18, '8.8', '13.7', '8.1', '13.2'),
(19, '8.9', '13.9', '8.2', '13.5'),
(20, '9.1', '14.2', '8.4', '13.7'),
(21, '9.2', '14.5', '8.6', '14'),
(22, '9.4', '14.7', '8.7', '14.3'),
(23, '9.5', '15', '8.9', '14.6'),
(24, '9.7', '15.3', '9', '14.8'),
(25, '9.8', '15.5', '9.2', '15.1'),
(26, '10', '15.8', '9.4', '15.4'),
(27, '10.1', '16.1', '9.5', '15.7'),
(28, '10.2', '16.3', '9.7', '16'),
(29, '10.4', '16.6', '9.8', '16.2'),
(30, '10.5', '16.9', '10', '16.5'),
(31, '10.7', '17.1', '10.1', '16.8'),
(32, '10.8', '17.4', '10.3', '17.1'),
(33, '10.9', '17.6', '10.4', '17.3'),
(34, '11.2', '18.1', '10.7', '17.6'),
(35, '11.3', '18.3', '10.8', '18.1'),
(36, '11.4', '18.6', '10.9', '18.4'),
(37, '11.5', '18.8', '11.1', '18.7'),
(38, '11.6', '19', '11.2', '19'),
(39, '11.8', '19.3', '11.3', '19.2'),
(40, '11.9', '19.5', '11.5', '19.5'),
(41, '12', '19.7', '11.6', '19.8'),
(42, '12.1', '20', '11.7', '20.1'),
(43, '12.2', '20.2', '11.8', '20.4'),
(44, '12.4', '20.5', '12.1', '20.7'),
(45, '12.5', '20.9', '12.2', '20.9'),
(46, '12.6', '20.9', '12.2', '21.2'),
(47, '12.7', '21.2', '12.3', '21.5'),
(48, '12.8', '21.4', '12.4', '21.8'),
(49, '12.9', '21.7', '12.6', '22.1'),
(50, '13.1', '21.9', '12.7', '22.4'),
(51, '13.2', '22.2', '12.8', '22.6'),
(52, '13.3', '22.4', '12.9', '22.9'),
(53, '13.5', '22.9', '13.2', '23.2'),
(54, '13.6', '23.2', '13.3', '23.8'),
(55, '13.7', '23.4', '13.4', '24.1'),
(56, '13.8', '23.7', '13.5', '24.4'),
(57, '14', '23.9', '13.6', '24.6'),
(58, '14.1', '24.2', '13.7', '24.9');

-- --------------------------------------------------------

--
-- Table structure for table `t_laporan_anak`
--

CREATE TABLE `t_laporan_anak` (
  `id_laporan` int(100) NOT NULL,
  `id_anak` int(100) NOT NULL,
  `umur_anak` varchar(100) NOT NULL,
  `berat_badan` varchar(10) DEFAULT NULL,
  `panjang_badan` varchar(10) DEFAULT NULL,
  `imunisasi` varchar(100) NOT NULL DEFAULT '-',
  `tanggal_timbang` datetime DEFAULT NULL,
  `vitamin` varchar(100) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_laporan_anak`
--

INSERT INTO `t_laporan_anak` (`id_laporan`, `id_anak`, `umur_anak`, `berat_badan`, `panjang_badan`, `imunisasi`, `tanggal_timbang`, `vitamin`) VALUES
(18, 1, '0', '2.9', '10', '-', '2016-09-25 00:00:00', '-'),
(19, 1, '1', '4', '12', '-', '2016-10-29 00:00:00', '-'),
(20, 1, '2', '4.5', '12.8', '-', '2016-11-25 00:00:00', '-');

-- --------------------------------------------------------

--
-- Table structure for table `t_laporan_ibu`
--

CREATE TABLE `t_laporan_ibu` (
  `id_laporan` int(100) NOT NULL,
  `id_ortu` int(100) NOT NULL,
  `lingkar_pinggang` varchar(10) NOT NULL DEFAULT '-',
  `lingkar_lengan` varchar(10) NOT NULL DEFAULT '-',
  `berat_badan` varchar(10) NOT NULL DEFAULT '-',
  `tinggi_badan` varchar(10) NOT NULL DEFAULT '-',
  `tanggal_timbang` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_laporan_ibu`
--

INSERT INTO `t_laporan_ibu` (`id_laporan`, `id_ortu`, `lingkar_pinggang`, `lingkar_lengan`, `berat_badan`, `tinggi_badan`, `tanggal_timbang`) VALUES
(1, 1, '2.3', '3.2', '49.5', '70.3', '2016-12-02 22:32:11');

-- --------------------------------------------------------

--
-- Table structure for table `t_ortu`
--

CREATE TABLE `t_ortu` (
  `id_ortu` int(100) NOT NULL,
  `ibu` varchar(100) NOT NULL,
  `ayah` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `tanggal_masuk` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_ortu`
--

INSERT INTO `t_ortu` (`id_ortu`, `ibu`, `ayah`, `alamat`, `tanggal_masuk`) VALUES
(1, 'mamik', 'budi', '', ''),
(2, 'yuli', 'mudi', '', ''),
(3, 'Yuli', 'Bidin', '', ''),
(4, 'yayuk', 'budi', '', ''),
(6, 'Yuni', 'Aliman', '', ''),
(9, 'Jamini', 'Sarman', 'Surabaya Barat', ''),
(10, 'Juliani', 'Ngateman', '', ''),
(11, 'santi', 'julianto', '', ''),
(13, 'Surni', 'Bebet', '', ''),
(16, 'Uma', 'Khoiri', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_admin`
--
ALTER TABLE `t_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `t_anak`
--
ALTER TABLE `t_anak`
  ADD PRIMARY KEY (`id_anak`),
  ADD KEY `id_ortu` (`id_ortu`);

--
-- Indexes for table `t_berat_badan`
--
ALTER TABLE `t_berat_badan`
  ADD PRIMARY KEY (`usia`);

--
-- Indexes for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  ADD PRIMARY KEY (`id_laporan`),
  ADD KEY `id_anak` (`id_anak`);

--
-- Indexes for table `t_laporan_ibu`
--
ALTER TABLE `t_laporan_ibu`
  ADD PRIMARY KEY (`id_laporan`),
  ADD KEY `id_ortu` (`id_ortu`);

--
-- Indexes for table `t_ortu`
--
ALTER TABLE `t_ortu`
  ADD PRIMARY KEY (`id_ortu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_admin`
--
ALTER TABLE `t_admin`
  MODIFY `id_admin` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `t_anak`
--
ALTER TABLE `t_anak`
  MODIFY `id_anak` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  MODIFY `id_laporan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `t_laporan_ibu`
--
ALTER TABLE `t_laporan_ibu`
  MODIFY `id_laporan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `t_ortu`
--
ALTER TABLE `t_ortu`
  MODIFY `id_ortu` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
