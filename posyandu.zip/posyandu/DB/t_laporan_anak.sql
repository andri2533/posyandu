-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2016 at 10:15 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `posyandu`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_laporan_anak`
--

CREATE TABLE `t_laporan_anak` (
  `id_laporan` int(100) NOT NULL,
  `id_anak` int(100) NOT NULL,
  `umur_anak` int(100) NOT NULL,
  `berat_anak` varchar(10) NOT NULL DEFAULT '-',
  `imunisasi` varchar(100) NOT NULL DEFAULT '-',
  `tanggal_timbang` datetime DEFAULT NULL,
  `vitamin` varchar(100) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_laporan_anak`
--

INSERT INTO `t_laporan_anak` (`id_laporan`, `id_anak`, `umur_anak`, `berat_anak`, `imunisasi`, `tanggal_timbang`, `vitamin`) VALUES
(1, 2, 0, '3.2', 'DB', '2016-11-27 16:05:40', 'AB & C'),
(2, 7, 0, '3.4', 'TBC', '2016-11-27 17:43:46', 'AB & C'),
(3, 1, 0, '3.2', '-', '2016-11-27 19:39:34', '-'),
(5, 7, 1, '4', 'AB', '2016-11-28 08:23:13', '-'),
(6, 2, 1, '4', '-', '2016-11-28 17:09:41', '-'),
(24, 1, 1, '-', '-', '2016-11-28 21:30:07', '-'),
(25, 5, 0, '2.6', '-', '2016-11-28 21:30:34', '-'),
(26, 10, 0, '2.3', '-', '2016-11-28 21:33:31', '-'),
(27, 11, 0, '-', '-', '2016-11-28 21:30:07', '-'),
(28, 12, 0, '-', '-', '2016-11-28 21:30:07', '-'),
(29, 13, 0, '2.8', '-', '2016-11-28 21:31:22', '-'),
(30, 1, 2, '4', 'DB', '2016-11-29 10:09:24', '-'),
(31, 2, 2, '-', '-', '2016-11-29 00:04:29', '-'),
(32, 5, 1, '-', '-', '2016-11-29 00:04:29', '-'),
(33, 7, 2, '-', '-', '2016-11-29 00:04:30', '-'),
(34, 10, 1, '-', '-', '2016-11-29 00:04:30', '-'),
(35, 11, 1, '-', '-', '2016-11-29 00:04:30', '-'),
(36, 12, 1, '-', '-', '2016-11-29 00:04:30', '-'),
(37, 13, 1, '-', '-', '2016-11-29 00:04:30', '-'),
(38, 1, 3, '-', '-', '2016-11-30 09:59:36', '-'),
(39, 2, 3, '-', '-', '2016-11-30 09:59:36', '-'),
(40, 5, 2, '-', '-', '2016-11-30 09:59:36', '-'),
(41, 7, 3, '-', '-', '2016-11-30 09:59:37', '-'),
(42, 10, 2, '-', '-', '2016-11-30 09:59:37', '-'),
(43, 11, 2, '-', '-', '2016-11-30 09:59:37', '-'),
(44, 12, 2, '-', '-', '2016-11-30 09:59:37', '-'),
(45, 13, 2, '-', '-', '2016-11-30 09:59:37', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  ADD PRIMARY KEY (`id_laporan`),
  ADD KEY `id_anak` (`id_anak`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  MODIFY `id_laporan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_laporan_anak`
--
ALTER TABLE `t_laporan_anak`
  ADD CONSTRAINT `t_laporan_anak_ibfk_2` FOREIGN KEY (`id_anak`) REFERENCES `t_anak` (`id_anak`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
